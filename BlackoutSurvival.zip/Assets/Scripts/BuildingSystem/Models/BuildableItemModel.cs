using Factories;
using UnityEngine;
using UnityEngine.Tilemaps;

namespace BuildingSystem.Models
{
	/// <summary>
	/// A base buildable item model scriptable object that we can use as a base of a buildable item. This class has:
	/// Name
	/// The preview sprite
	/// Prefab of the buildable
	/// Cell size of the building (4x4 for barracks, 2x3 for power plants for now)
	/// Health
	/// And Building Type.
	/// </summary>
	[CreateAssetMenu(menuName = "BuildingSystem/Create New Buildable Item")]
	public class BuildableItemModel : ScriptableObject
	{
		/// <summary>
		/// Name of the buildable item
		/// </summary>
	   [field: SerializeField]
	   public string Name { get; private set; }
	   
	   /// <summary>
	   /// Tile that can be used to paint the building layer.
	   /// </summary>
	   [field: SerializeField]
	   public TileBase Tile { get; private set; }
	   
	   /// <summary>
	   /// The preview sprite of the buildable item
	   /// </summary>
	   [field: SerializeField]
	   public Sprite PreviewSprite { get; private set; }
	   
	   /// <summary>
	   /// Prefab of the buildable
	   /// </summary>
	   [field: SerializeField]
	   public GameObject GameObjectPrefab { get; private set; }
	   
	   /// <summary>
	   /// Cell size of the building (4x4 for barracks, 2x3 for power plants for now)
	   /// </summary>
	   [field: SerializeField]
	   public RectInt CellBoundaries { get; private set; }
	   
	   /// <summary>
	   /// Initial health of the buildable item.
	   /// </summary>
	   [field: SerializeField]
	   public int Health { get; private set; }

	   /// <summary>
	   /// Type of the buildable item.
	   /// </summary>
	   [field: SerializeField]
	   public BuildingType BuildingType { get; private set; }
	   
	}
}
