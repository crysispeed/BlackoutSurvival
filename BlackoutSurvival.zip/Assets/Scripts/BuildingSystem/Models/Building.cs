using System;
using Extensions;
using Factories;
using PoolingSystems;
using UnityEngine;
using UnityEngine.Tilemaps;
using Object = UnityEngine.Object;

namespace BuildingSystem.Models
{
	/// <summary>
	/// This class is mainly used for registering and unregistering to the tilemap operations.
	/// </summary>
	[Serializable]
	public class Building
	{
		/// <summary>
		/// Tilemap of the building in case if we want to build to the different tilemap layer.
		/// </summary>
		[field: SerializeField]
		public Tilemap ParentTilemap { get; private set; }
		
		/// <summary>
		/// Buildable item model reference for base and unchanged info.
		/// </summary>
		[field: SerializeField]
		public BuildableItemModel BuildableItemModel { get; private set; }
		
		/// <summary>
		/// Game object reference for pooling purposes.
		/// </summary>
		[field: SerializeField]
		public GameObject GameObject { get; private set; }
		
		/// <summary>
		/// Coordinates of the building. (Coordinate is the center of the building.)
		/// </summary>
		[field: SerializeField]
		public Vector3Int Coordinates { get; private set; }
		
		/// <summary>
		/// Type of the building.
		/// </summary>
		public BuildingType BuildingType { get; private set; }
		
		public Building(
			BuildableItemModel buildableItemModel,
			Vector3Int coordinates,
			Tilemap parentTilemap,
			BuildingType buildingType,
			GameObject obj = null)
		{
			ParentTilemap = parentTilemap;
			Coordinates = coordinates;
			GameObject = obj;
			BuildingType = buildingType;
			BuildableItemModel = buildableItemModel;
		}

		public void Destroy()
		{
			if (GameObject != null)
			{
				BuildingFactory.Instance.ReturnBuildingGameObject(BuildingType, GameObject);
			}
		}

		/// <summary>
		/// Iterates to the cell boundaries of the building to do any action we want for that specific cell.
		/// </summary>
		/// <param name="action"></param>
		public void IterateCellBoundaries(RectIntExtension.RectAction action)
		{
			// Our buildings are centered, so we need to get the top left coordinates by substracting the original coordinate by width and height.
			Vector3Int coordinates = new Vector3Int(Coordinates.x - Mathf.CeilToInt(BuildableItemModel.CellBoundaries.width / 2), Coordinates.y -
				Mathf.CeilToInt(BuildableItemModel.CellBoundaries.height / 2), 0);
			BuildableItemModel.CellBoundaries.Iterate(coordinates, action);
		}
	}
}
