using UnityEngine;
using UnityEngine.Serialization;

namespace BuildingSystem.Models
{
	/// <summary>
	/// This class inherits from Buildable item model, since barracks can create soldiers.
	/// </summary>
	[CreateAssetMenu(menuName = "BuildingSystem/Create Barracks")]
	public class BarracksModel : BuildableItemModel
	{
		public GameObject[] SoldierPrefabs;
	}
}
