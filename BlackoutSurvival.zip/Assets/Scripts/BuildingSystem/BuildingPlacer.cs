using System;
using System.Collections.Generic;
using BuildingSystem.Controllers;
using BuildingSystem.Models;
using BuildingSystem.TilemapLayerLogic;
using GameInput;
using Soldiers;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.Serialization;
using UnityEngine.UI;

namespace BuildingSystem
{
	/// <summary>
	/// Handles the building placement in the play field. Checks the current layers and decides if we can place the building or not.
	/// </summary>
	public class BuildingPlacer : MonoBehaviour
	{
		public static BuildingPlacer Instance { get; private set; }

		[field: SerializeField]
		public BuildableItemModel ActiveBuildableItemModel { get; private set; }

		[FormerlySerializedAs("_constructionLayer")] [SerializeField]
		private BuildingLayer BuildingLayer;

		[FormerlySerializedAs("_previewLayer")] [SerializeField]
		private PreviewLayer PreviewLayer;

		[FormerlySerializedAs("_mainLayer")] [SerializeField]
		private MainLayer MainLayer;
		
		private GraphicRaycaster _raycaster;
		private EventSystem _eventSystem;
		
		private void Awake()
		{
			if (Instance != null && Instance != this)
			{
				Destroy(this);
			}
			else
			{
				Instance = this;
			}

			if (_raycaster == null)
				_raycaster = FindObjectOfType<GraphicRaycaster>();
			if (_eventSystem == null)
				_eventSystem = FindObjectOfType<EventSystem>();
		}

		private void Update()
		{
			if (BuildingLayer == null)
				return;
			
			if (IsMousePointerOnUIElement() || IsMouseOutsideWindow())
			{
				PreviewLayer.ClearPreview();
				return;
			}

			var mousePos = MouseInputController.Instance.MouseInWorldPosition;
			if (MouseInputController.Instance.IsMouseButtonPressed(MouseButton.Middle) && ActiveBuildableItemModel == null)
			{
				BuildingLayer.DestroyBuilding(mousePos);
				return;
			}

			if (ActiveBuildableItemModel == null)
			{
				return;
			}
			
			if (MouseInputController.Instance.IsMouseButtonPressed(MouseButton.Right))
			{
				PreviewLayer.ClearPreview();
				ActiveBuildableItemModel = null;
				return;
			}

			PreviewLayer.ShowPreview(ActiveBuildableItemModel, mousePos,
				BuildingLayer.IsCoordinateEmpty(mousePos, ActiveBuildableItemModel.CellBoundaries) && MainLayer.IsBuildable(mousePos, ActiveBuildableItemModel.CellBoundaries)
				&& !IsMouseOverlapsObject(mousePos));

			if (MouseInputController.Instance.IsMouseButtonPressed(MouseButton.Left) &&
				BuildingLayer.IsCoordinateEmpty(mousePos, ActiveBuildableItemModel.CellBoundaries) &&
				MainLayer.IsBuildable(mousePos, ActiveBuildableItemModel.CellBoundaries))
			{
				BuildingLayer.Build(mousePos, ActiveBuildableItemModel);
			}
		}

		public void SetActiveBuildableItem(BuildableItemModel buildableItemModel)
		{
			ActiveBuildableItemModel = buildableItemModel;
		}

		private bool IsMousePointerOnUIElement()
		{
			PointerEventData eventData = new PointerEventData(_eventSystem);
			eventData.position = Input.mousePosition;

			List<RaycastResult> results = new List<RaycastResult>();
			_raycaster.Raycast(eventData, results);

			return results.Count > 0; // If results list is not empty, mouse is over a UI element
		}

		private bool IsMouseOutsideWindow()
		{
			Vector3 mousePos = Input.mousePosition;
			return mousePos.x < 0 || mousePos.x > Screen.width || mousePos.y < 0 || mousePos.y > Screen.height;
		}

		private bool IsMouseOverlapsObject(Vector2 mousePos)
		{
			RaycastHit2D hit = Physics2D.Raycast(mousePos, Vector2.zero, 0f);
			
			var hitBuildingComponent = hit.collider?.GetComponent<BuildingController>();
			var hitSoldierComponent = hit.collider?.GetComponent<Soldier>();
			
			return hitBuildingComponent != null || hitSoldierComponent != null;
		}
	}
}