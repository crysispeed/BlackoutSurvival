using System.Collections.Generic;
using BuildingSystem.Models;
using Extensions;
using Factories;
using Pathfinding;
using PoolingSystems;
using UnityEngine;

namespace BuildingSystem.TilemapLayerLogic
{
	/// <summary>
	/// This class handles the building layer that we can instantiate new buildings. It also holds the buildings on the specific coordinates to check whether we can build a building on that coordinate or not.
	/// </summary>
	public class BuildingLayer : TilemapLayer
	{
		private Dictionary<Vector3Int, Building> _buildingCoordinates = new Dictionary<Vector3Int, Building>();
		
		public void Build(Vector3 worldCoordinate, BuildableItemModel itemModel)
		{
			GameObject itemGameObject = null;

			var tileCoordinates = Tilemap.WorldToCell(worldCoordinate);
			if (itemModel.Tile != null)
			{
				Tilemap.SetTile(tileCoordinates, itemModel.Tile);
			}

			if (itemModel.GameObjectPrefab != null)
			{
				itemGameObject = BuildingFactory.Instance.CreateBuildingGameObject(itemModel.BuildingType, Tilemap.CellToWorld(tileCoordinates) + Tilemap.cellSize / 2);
			}

			var buildable = new Building(itemModel, tileCoordinates, Tilemap, itemModel.BuildingType, itemGameObject);
			RegisterBuildableCellBoundaries(buildable);
			
			GridManager.Instance.GenerateGrid();
		}

		public void DestroyBuilding(Vector3 worldCoordinate)
		{
			var tileCoordinates = Tilemap.WorldToCell(worldCoordinate);
			if (!_buildingCoordinates.TryGetValue(tileCoordinates, out var buildable))
				return;

			UnregisterBuildableCellBoundaries(buildable);
			buildable.Destroy();
			
			GridManager.Instance.GenerateGrid();
		}

		public bool IsCoordinateEmpty(Vector3 worldCoordinate, RectInt cellBoundaries)
		{
			var tileCoordinates = Tilemap.WorldToCell(worldCoordinate);
			Vector3Int centeredCoordinates = new Vector3Int(tileCoordinates.x - Mathf.CeilToInt(cellBoundaries.width / 2), tileCoordinates.y - Mathf.CeilToInt(cellBoundaries.height / 2), 0);
			return !IsRectOccupied(centeredCoordinates, cellBoundaries);
		}

		private void RegisterBuildableCellBoundaries(Building building)
		{
			building.IterateCellBoundaries(tileCoordinates => _buildingCoordinates.Add(tileCoordinates, building));
		}

		private void UnregisterBuildableCellBoundaries(Building building)
		{
			building.IterateCellBoundaries(tileCoordinates => _buildingCoordinates.Remove(tileCoordinates));
		}

		private bool IsRectOccupied(Vector3Int tileCoordinates, RectInt rect)
		{
			return rect.IterateCheck(tileCoordinates, tileCoords => _buildingCoordinates.ContainsKey(tileCoords));
		}
	}
}