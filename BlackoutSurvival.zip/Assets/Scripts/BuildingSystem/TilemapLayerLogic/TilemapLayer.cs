using UnityEngine;
using UnityEngine.Tilemaps;

namespace BuildingSystem.TilemapLayerLogic
{
    /// <summary>
    /// Tilemap layer class to be used as a base class for all of the tilemap layers that we have (Building, main and preview layers.)
    /// </summary>
    [RequireComponent(typeof(Tilemap))]
    public class TilemapLayer : MonoBehaviour
    {
        protected Tilemap Tilemap {get; private set;}
        // Start is called before the first frame update
        private void Awake()
        {
            Tilemap = GetComponent<Tilemap>();
        }
    }
}
