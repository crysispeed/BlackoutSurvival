using Extensions;
using UnityEngine;
using UnityEngine.Serialization;
using UnityEngine.Tilemaps;

namespace BuildingSystem.TilemapLayerLogic
{
    /// <summary>
    /// Main tilemap layer class which holds the background of the playable field that you can see at the backround.
    /// <remarks>Right now we can only build to the green grass tile.</remarks>
    /// </summary>
    public class MainLayer : TilemapLayer
    {
        [FormerlySerializedAs("_buildableTileSprite")] [SerializeField]
        private Sprite BuildableTileSprite;
        
        public bool IsBuildable(Vector3 worldCoordinate, RectInt cellBoundaries)
        {
            var tileCoordinates = Tilemap.WorldToCell(worldCoordinate);
            Vector3Int centeredCoordinates = new Vector3Int(tileCoordinates.x - Mathf.CeilToInt(cellBoundaries.width / 2),
                tileCoordinates.y - Mathf.CeilToInt(cellBoundaries.height / 2), 0);
            return !IsRectOccupied(centeredCoordinates, cellBoundaries);
        }

        private bool IsRectOccupied(Vector3Int tileCoordinates, RectInt rect)
        {
            return rect.IterateCheck(tileCoordinates, tileCoords => Tilemap.GetSprite(tileCoords) != BuildableTileSprite);
        }
    }
}
