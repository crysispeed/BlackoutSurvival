using BuildingSystem.Models;
using UnityEngine;

namespace BuildingSystem.TilemapLayerLogic
{
    /// <summary>
    /// Preview layer for showing the preview of the selected building in the play field. This layer enabled when we select a building from infinitely scrollable view.
    /// </summary>
    public class PreviewLayer : TilemapLayer
    {
        [SerializeField]
        private SpriteRenderer _spriteRenderer;

        public void ShowPreview(
            BuildableItemModel buildableItemModel,
            Vector3 position,
            bool isValid)
        {
            // Ensuring we have true world position, in case cell size changes to bigger or smaller.
            var tilemapCoordinates = Tilemap.WorldToCell(position);
            _spriteRenderer.enabled = true;
            _spriteRenderer.transform.position = Tilemap.CellToWorld(tilemapCoordinates) + Tilemap.cellSize / 2;
            _spriteRenderer.sprite = buildableItemModel.PreviewSprite;
            _spriteRenderer.color = isValid ? Color.green : Color.red;
        }

        public void ClearPreview()
        {
            _spriteRenderer.enabled = false;
        }
    }
}
