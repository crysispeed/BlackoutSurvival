using UnityEngine;

namespace BuildingSystem.Controllers
{
    /// <summary>
    /// This empty class is inherited from building controller for future-proof implementations that Barracks building can have.
    /// </summary>
    public class BarracksController : BuildingController
    {
       
    }
}
