using System;
using BuildingSystem.Models;
using BuildingSystem.TilemapLayerLogic;
using TMPro;
using UI.ViewModels;
using Unity.VisualScripting;
using UnityEngine;

namespace BuildingSystem.Controllers
{
    /// <summary>
    /// Main building controller to handle damages, and holds the data of the created building to use in other scripts.
    /// </summary>
    public class BuildingController : MonoBehaviour
    {
        public BuildableItemModel BuildableItemModel;
        public GameObject SelectedSpriteGameObject;
        public TMP_Text HealthText;
        
        private BuildingLayer _buildingLayer;
        private int _health;
        
        private void Awake()
        {
            _buildingLayer = GameObject.FindGameObjectWithTag("BuildingLayer").GetComponent<BuildingLayer>();
        }

        public void Initialize()
        {
            _health = BuildableItemModel.Health;
            HealthText.text = _health.ToString();
        }
        
        public void SetBuildingSelected(bool isSelected)
        {
            SelectedSpriteGameObject.SetActive(isSelected);
        }

        public int GetHealth()
        {
            return _health;
        }
        
        public void TakeDamage(int damage)
        {
            _health -= damage;
            Debug.Log($"{name} took {damage} damage. Remaining health: {_health}");
            HealthText.text = _health.ToString();
            
            if (_health <= 0)
            {
                DestroyBuilding();
            }
        }

        private void DestroyBuilding()
        {
            Debug.Log($"{name} has been destroyed!");
            _buildingLayer.DestroyBuilding(transform.position);
        }
    }
}
