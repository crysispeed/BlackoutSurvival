using UnityEngine;

namespace Soldiers
{
	/// <summary>
	/// Infantry class that is inherited from base Soldier class. These classes are future-proof classes in case for future soldier type-specific behaviours.
	/// </summary>
	public class Infantry : Soldier
	{
		public override void Initialize()
		{
			base.Initialize();
			Debug.Log("Infantry soldier created!");
		}
	}
}