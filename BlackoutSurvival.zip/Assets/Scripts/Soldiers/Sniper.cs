using UnityEngine;

namespace Soldiers
{
	/// <summary>
	/// Sniper class that is inherited from base Soldier class. These classes are future-proof classes in case for future soldier type-specific behaviours.
	/// </summary>
	public class Sniper : Soldier
	{
		public override void Initialize()
		{
			base.Initialize();
			Debug.Log("Sniper soldier created!");
		}
	}
}