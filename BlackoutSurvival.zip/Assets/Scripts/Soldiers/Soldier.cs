using System.Collections;
using System.Collections.Generic;
using BuildingSystem.Controllers;
using Factories;
using Pathfinding;
using UnityEngine;
using UnityEngine.Serialization;

namespace Soldiers
{
	/// <summary>
	/// Base soldier class that holds all the soldier data. Also handles the attacking, damage logic, moving based on the path from A*, and dying.
	/// </summary>
	public abstract class Soldier : MonoBehaviour
	{
		public int MaxHealth = 10;
		public int AttackDamage = 2;
		public float MoveSpeed = 2f;
        public float AttackSpeed = 1f;
		public GameObject SelectedSpriteGameObject;

		private List<Vector2Int> _path;
		private Coroutine _followPathCoroutine;
		private BuildingController _targetBuilding;
		private Soldier _targetSoldier;
		private int _currentHealth;
		private int _currentPathIndex;
		private bool _isAttacking = false;
		
		public virtual void Initialize()
		{
			_currentHealth = MaxHealth;
		}

		public void MoveTo(Vector2 targetPosition, System.Action onReached = null)
		{
			Vector2Int startGridPos = Vector2Int.FloorToInt(transform.position);
			Vector2Int endGridPos = Vector2Int.FloorToInt(targetPosition);
			
			// Preventing spamming right click which can cause null path in coroutine.
			List<Vector2Int> newPath = AStarPathfinding.FindPath(startGridPos, endGridPos);

			if (newPath == null || newPath.Count == 0)
			{
				Debug.LogWarning("Cannot move: No valid path found.");
				return;
			}

			_path = newPath;
			if (_path != null && _path.Count > 0)
			{
				_currentPathIndex = 0;
				if(_followPathCoroutine != null)
					StopCoroutine(_followPathCoroutine);
				
				_followPathCoroutine = StartCoroutine(FollowPath(onReached));
			}
		}

		public void MoveAndAttackBuilding(BuildingController target, List<Soldier> selectedSoldiers)
		{
			StopAllCoroutines(); // Ensure previous attacks stop before starting a new one.
			
			_targetBuilding = target;
			Vector2 attackPosition = GetNearestValidAttackPosition(target, 1f);

			MoveTo(attackPosition, () =>
			{
				if (_targetBuilding == target) // Ensure we are still targeting the right building
				{
					Debug.Log($"Reached attack position, attacking {target.name}");
					StartCoroutine(AttackBuilding());
				}
			});
		}

		public void MoveAndAttackSoldier(Soldier target)
		{
			StopAllCoroutines(); // Stop previous attack

			_targetSoldier = target; // Set new target

			// Get attack position with a gap
			Vector2 attackPosition = GridManager.Instance.GetNearestValidAttackPosition(target.transform.position, transform.position, 1f);

			MoveTo(attackPosition, () =>
			{
				if (_targetSoldier == target)
				{
					StartCoroutine(AttackSoldier());
				}
			});
		}

		private IEnumerator AttackSoldier()
		{
			while (_targetSoldier != null && _targetSoldier._currentHealth > 0)
			{
				
				if (_targetSoldier == null)
					yield break;
				
				_targetSoldier.TakeDamage(AttackDamage);
				Debug.Log($"{gameObject.name} attacked {_targetSoldier.name} for {AttackDamage} damage. Remaining health: {_targetSoldier._currentHealth}");
				
				yield return new WaitForSeconds(AttackSpeed);
			}

			if (_targetSoldier != null && _targetSoldier._currentHealth <= 0)
			{
				_targetSoldier.Die();
			}
		}

		private IEnumerator AttackBuilding()
		{
			if (_isAttacking || _targetBuilding == null)
				yield break;
			
			_isAttacking = true;
			while (_targetBuilding != null && _targetBuilding.GetHealth() > 0)
			{
				Debug.Log($"{name} attacks {_targetBuilding.name} for {_targetBuilding.GetHealth()} damage.");
				_targetBuilding.TakeDamage(AttackDamage);

				yield return new WaitForSeconds(AttackSpeed);
			}

			_isAttacking = false;
		}

		private Vector2 GetNearestValidAttackPosition(BuildingController target, float gap)
		{
			// Get nearest empty tile around the building
			return GridManager.Instance.GetClosestValidTile(target.transform.position, transform.position, target, gap);
		}
		
		private IEnumerator FollowPath(System.Action onReached)
		{
			if(_path == null || _path.Count == 0)
				yield break;
			
			while (_currentPathIndex < _path.Count)
			{
				Vector3 targetWorldPos = new Vector3(_path[_currentPathIndex].x, _path[_currentPathIndex].y, 0);
				while (Vector3.Distance(transform.position, targetWorldPos) > 0.1f)
				{
					transform.position = Vector3.MoveTowards(transform.position, targetWorldPos, MoveSpeed * Time.deltaTime);
					yield return null;
				}

				_currentPathIndex++;
			}

			onReached?.Invoke();
		}

		public void SetSoldierSelected(bool isSelected)
		{
			SelectedSpriteGameObject.SetActive(isSelected);
		}

		private void TakeDamage(int damage)
		{
			_currentHealth -= damage;

			if (_currentHealth <= 0)
			{
				Die();
			}
		}

		private void Die()
		{
			Debug.Log($"{name} Died!");
			SoldierFactory.Instance.ReturnSoldier(this);
		}
	}
}