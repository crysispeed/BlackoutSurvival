using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace GameInput
{
    /// <summary>
    /// This is just an extension clas to singleton the input actions that we can use in input controllers.
    /// </summary>
    public partial class InputActions
    {
        private static InputActions _instance;

        public static InputActions Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new InputActions();
                    _instance.Enable();
                }
                
                return _instance;
            }
            
            private set => _instance = value;
        }
    }
    
}
