using System;
using System.Collections;
using System.Collections.Generic;
using GameInput;
using UnityEngine;
using UnityEngine.InputSystem;

namespace GameInput
{
    public enum MouseButton
    {
        Left,
        Right,
        Middle
    }

    /// <summary>
    /// This class handles the mouse input operations. We are using Input Actions asset that Unity has, which helps us to handle inputs way more convenient and safe.
    /// </summary>
    public class MouseInputController : MonoBehaviour
    {
        private InputActions _inputActions;
        public static MouseInputController Instance { get; private set; }
        public Vector2 MousePosition {get; private set;}
        public Vector2 MouseInWorldPosition => Camera.main.ScreenToWorldPoint(MousePosition);
        
        private bool _isLeftMouseClicked = false;
        private bool _isRightMouseClicked = false;
        private bool _isMiddleMouseClicked = false;
        private float _mouseScrollWheelValue = 0;

        private void Awake()
        {
            if (Instance != null && Instance != this)
            {
                Destroy(this);
            }
            else
            {
                Instance = this;
            }
        }

        private void OnEnable()
        {
            _inputActions = InputActions.Instance;
            _inputActions.GameManagement.MousePosition.performed += OnMousePositionPerformed;
            _inputActions.GameManagement.Build.performed += OnBuildActionPerformed;
            _inputActions.GameManagement.Build.canceled += OnBuildActionCancelled;
            _inputActions.GameManagement.Cancel.performed += OnCancelActionPerformed;
            _inputActions.GameManagement.Cancel.canceled += OnCancelActionCancelled;
            _inputActions.GameManagement.DestroyBuilding.performed += OnDestroyBuildingActionPerformed;
            _inputActions.GameManagement.DestroyBuilding.canceled += OnDestroyBuildingActionCancelled;
            _inputActions.GameManagement.ZoomCamera.performed += OnZoomCameraActionPerformed;
            _inputActions.GameManagement.ZoomCamera.canceled += OnZoomCameraActionCancelled;
        }


        private void OnDisable()
        {
            _inputActions.GameManagement.MousePosition.performed -= OnMousePositionPerformed;
            _inputActions.GameManagement.Build.performed -= OnBuildActionPerformed;
            _inputActions.GameManagement.Build.canceled -= OnBuildActionCancelled;
            _inputActions.GameManagement.Cancel.performed -= OnCancelActionPerformed;
            _inputActions.GameManagement.Cancel.canceled -= OnCancelActionCancelled;
            _inputActions.GameManagement.DestroyBuilding.performed -= OnDestroyBuildingActionPerformed;
            _inputActions.GameManagement.DestroyBuilding.canceled -= OnDestroyBuildingActionCancelled;
            _inputActions.GameManagement.ZoomCamera.performed -= OnZoomCameraActionPerformed;
            _inputActions.GameManagement.ZoomCamera.canceled -= OnZoomCameraActionCancelled;
        }

        private void OnZoomCameraActionPerformed(InputAction.CallbackContext obj)
        {
            _mouseScrollWheelValue = obj.ReadValue<Vector2>().y;
        }

        private void OnZoomCameraActionCancelled(InputAction.CallbackContext obj)
        {
            _mouseScrollWheelValue = 0;
        }

        private void OnBuildActionPerformed(InputAction.CallbackContext context)
        {
            _isLeftMouseClicked = true;
        }

        private void OnBuildActionCancelled(InputAction.CallbackContext context)
        {
            _isLeftMouseClicked = false;
        }

        private void OnCancelActionPerformed(InputAction.CallbackContext context)
        {
            _isRightMouseClicked = true;
        }

        private void OnCancelActionCancelled(InputAction.CallbackContext context)
        {
            _isRightMouseClicked = false;
        }
        
        private void OnDestroyBuildingActionPerformed(InputAction.CallbackContext context)
        {
            _isMiddleMouseClicked = true;
        }

        private void OnDestroyBuildingActionCancelled(InputAction.CallbackContext context)
        {
            _isMiddleMouseClicked = false;
        }
        
        private void OnMousePositionPerformed(InputAction.CallbackContext context)
        {
            MousePosition = context.ReadValue<Vector2>();
        }
        
        public bool IsMouseButtonPressed(MouseButton button)
        {
            return button switch
            {
                MouseButton.Left => _isLeftMouseClicked,
                MouseButton.Right => _isRightMouseClicked,
                _ => _isMiddleMouseClicked
            };
        }

        public float GetMouseScrollWheelValue()
        {
            return _mouseScrollWheelValue;
        }
    }
    
}
