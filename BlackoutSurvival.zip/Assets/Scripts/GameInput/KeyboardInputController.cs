using UnityEngine;
using UnityEngine.InputSystem;

namespace GameInput
{
	public enum KeyboardButton
	{
		MoveUp,
		MoveDown,
		MoveLeft,
		MoveRight,
		None
	}

	/// <summary>
	/// This class handles the keyboard input operations. We are using Input Actions asset that Unity has, which helps us to handle inputs way more convenient and safe.
	/// </summary>
	public class KeyboardInputController : MonoBehaviour
	{
		public static KeyboardInputController Instance { get; private set; }
		
		private InputActions _inputActions;
		private KeyboardButton _currentKeyboardButton = KeyboardButton.None;
		
		private void Awake()
		{
			if (Instance != null && Instance != this)
			{
				Destroy(this);
			}
			else
			{
				Instance = this;
			}
		}

		private void OnEnable()
		{
			_inputActions = InputActions.Instance;
			_inputActions.GameManagement.CameraMoveLeft.performed += OnCameraMoveLeftActionPerformed;
			_inputActions.GameManagement.CameraMoveRight.performed += OnCameraMoveRightActionPerformed;
			_inputActions.GameManagement.CameraMoveUp.performed += OnCameraMoveUpActionPerformed;
			_inputActions.GameManagement.CameraMoveDown.performed += OnCameraMoveDownActionPerformed;
			_inputActions.GameManagement.CameraMoveLeft.canceled += OnCameraMoveCancelled;
			_inputActions.GameManagement.CameraMoveRight.canceled += OnCameraMoveCancelled;
			_inputActions.GameManagement.CameraMoveUp.canceled += OnCameraMoveCancelled;
			_inputActions.GameManagement.CameraMoveDown.canceled += OnCameraMoveCancelled;

		}

		private void OnDisable()
		{
			_inputActions.GameManagement.CameraMoveLeft.performed -= OnCameraMoveLeftActionPerformed;
			_inputActions.GameManagement.CameraMoveRight.performed -= OnCameraMoveRightActionPerformed;
			_inputActions.GameManagement.CameraMoveUp.performed -= OnCameraMoveUpActionPerformed;
			_inputActions.GameManagement.CameraMoveDown.performed -= OnCameraMoveDownActionPerformed;
			_inputActions.GameManagement.CameraMoveLeft.canceled -= OnCameraMoveCancelled;
			_inputActions.GameManagement.CameraMoveRight.canceled -= OnCameraMoveCancelled;
			_inputActions.GameManagement.CameraMoveUp.canceled -= OnCameraMoveCancelled;
			_inputActions.GameManagement.CameraMoveDown.canceled -= OnCameraMoveCancelled;
		}
		private void OnCameraMoveCancelled(InputAction.CallbackContext obj)
		{
			_currentKeyboardButton = KeyboardButton.None;
		}

		private void OnCameraMoveDownActionPerformed(InputAction.CallbackContext obj)
		{
			_currentKeyboardButton = KeyboardButton.MoveDown;
		}

		private void OnCameraMoveUpActionPerformed(InputAction.CallbackContext obj)
		{
			_currentKeyboardButton = KeyboardButton.MoveUp;
		}

		private void OnCameraMoveRightActionPerformed(InputAction.CallbackContext obj)
		{
			_currentKeyboardButton = KeyboardButton.MoveRight;
		}

		private void OnCameraMoveLeftActionPerformed(InputAction.CallbackContext obj)
		{
			_currentKeyboardButton = KeyboardButton.MoveLeft;
		}

		public KeyboardButton GetCurrentKeyboardButton()
		{
			return _currentKeyboardButton;
		}
	}
}