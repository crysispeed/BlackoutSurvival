using UnityEngine;
using UnityEngine.UI;

namespace UI.ListView
{
	/// <summary>
	/// This handles the infinite scroll view behaviour that you can scroll the building list view indefinitely.
	/// </summary>
	public class InfiniteScrollViewController : MonoBehaviour
	{
		[SerializeField]
		private ScrollRect ScrollRect;

		[SerializeField]
		private RectTransform ViewportTransform;

		[SerializeField]
		private RectTransform ContentTransform;

		[SerializeField]
		private VerticalLayoutGroup VerticalLayoutGroup;

		[SerializeField]
		private RectTransform[] ItemList;

		private Vector2 _oldVelocity;
		private bool _isUpdated;
		
		// Start is called before the first frame update
		void Start()
		{
			int itemsToAdd = Mathf.CeilToInt(ViewportTransform.rect.height / (ItemList[0].rect.height + VerticalLayoutGroup.spacing));

			for (int i = 0; i < itemsToAdd; i++)
			{
				int num = ItemList.Length - i - 1;

				while (num < 0)
				{
					num += ItemList.Length;
				}

				RectTransform item = Instantiate(ItemList[num], ContentTransform);
				item.SetAsFirstSibling();
			}

			ContentTransform.localPosition = new Vector3(ContentTransform.localPosition.x, (ItemList[0].rect.height + VerticalLayoutGroup.spacing) * itemsToAdd,
				ContentTransform.localPosition.z);
		}

		// Update is called once per frame
		void Update()
		{
			if (_isUpdated)
			{
				_isUpdated = false;
				ScrollRect.velocity = _oldVelocity;
			}

			var yPosition = ItemList.Length * (ItemList[0].rect.height + VerticalLayoutGroup.spacing);
			if (ContentTransform.localPosition.y > 0)
			{
				Canvas.ForceUpdateCanvases();
				_oldVelocity = ScrollRect.velocity;
				ContentTransform.localPosition -= new Vector3(0, yPosition, 0);
				_isUpdated = true;
			}
			else if (ContentTransform.localPosition.y < 0 - yPosition)
			{
				Canvas.ForceUpdateCanvases();
				_oldVelocity = ScrollRect.velocity;
				ContentTransform.localPosition += new Vector3(0, yPosition, 0);
				_isUpdated = true;
			}
		}
	}
}