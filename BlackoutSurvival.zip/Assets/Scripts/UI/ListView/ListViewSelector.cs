using BuildingSystem;
using BuildingSystem.Models;
using UnityEngine;

namespace UI.ListView
{
    /// <summary>
    /// This only handles the button interaction of the list view item. When we press to the list item, we are setting the active building for preview so that we can place to the play field.
    /// </summary>
    public class ListViewSelector : MonoBehaviour
    {
        public void UpdateBuildableItem(BuildableItemModel itemModel)
        {
            BuildingPlacer.Instance.SetActiveBuildableItem(itemModel);
        }
    }
}
