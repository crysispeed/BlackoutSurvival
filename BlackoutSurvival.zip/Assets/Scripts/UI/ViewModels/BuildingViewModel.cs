using System;
using System.Collections.Generic;
using BuildingSystem.Controllers;
using BuildingSystem.Models;
using Factories;
using Soldiers;
using TMPro;
using UnityEngine;
using UnityEngine.Serialization;
using UnityEngine.UI;
using Random = UnityEngine.Random;

namespace UI.ViewModels
{
    /// <summary>
    /// <para>This is the view model for right side of the canvas that shows the selected buildings info.</para>
    /// <para>Barracks can spawn soldiers by clicking to the buttons under selected building image.</para>
    /// <para>Power plant does not have anything in particular, just image and the name of the building.</para>
    /// </summary>
    public class BuildingViewModel : MonoBehaviour
    {
        public static Action<BuildableItemModel> OnBuildingSelected;
        public static Action OnBuildingDeselected;

        public TMP_Text BuildingNameText;
        public Image BuildingImage;
        public GameObject SoldierButtonsPanel; // Container for soldier buttons
        public Button[] SoldierButtons; // Buttons to spawn soldiers

        private readonly float _spawnRadius = 1.0f; // Distance from barracks
        private readonly int _maxSpawnAttempts = 10; // Avoid infinite loops
        
        private List<Vector2> _occupiedPositions = new List<Vector2>();
        private BuildableItemModel _currentBuilding;
        private GameObject _selectedBuildingGameObject;

        private void OnEnable()
        {
            OnBuildingSelected += UpdateUI;
            OnBuildingDeselected += HideUI;
        }

        private void OnDisable()
        {
            OnBuildingSelected -= UpdateUI;
           OnBuildingDeselected -= HideUI;
        }

        private void HideUI()
        {
            SoldierButtonsPanel.SetActive(false);
            BuildingImage.enabled = false;
            BuildingNameText.text = "";
        }
        
        public void SelectBuilding(BuildableItemModel building, GameObject buildingGameObject)
        {
            if(_selectedBuildingGameObject != null)
                DeselectBuilding();
            
            _currentBuilding = building;
            _selectedBuildingGameObject = buildingGameObject;
            _selectedBuildingGameObject.GetComponent<BuildingController>().SetBuildingSelected(true);
            OnBuildingSelected?.Invoke(building);
        }

        public void DeselectBuilding()
        {
            if(_selectedBuildingGameObject == null)
                return;
            
            _selectedBuildingGameObject.GetComponent<BuildingController>().SetBuildingSelected(false);
            _currentBuilding = null;
            _selectedBuildingGameObject = null;
            OnBuildingDeselected?.Invoke();
        }

        private void UpdateUI(BuildableItemModel building)
        {
            BuildingNameText.text = building.Name;
            BuildingImage.sprite = building.PreviewSprite;
            BuildingImage.enabled = true;
            if (building is BarracksModel barracks)
            {
                SoldierButtonsPanel.SetActive(true);

                for (int i = 0; i < SoldierButtons.Length; i++)
                {
                    SoldierButtons[i].onClick.RemoveAllListeners();
                    SoldierButtons[i].gameObject.SetActive(true);
                }
                
                SoldierButtons[0].onClick.AddListener(() => SpawnSoldier(SoldierType.Infantry));
                SoldierButtons[1].onClick.AddListener(() => SpawnSoldier(SoldierType.Sniper));
                SoldierButtons[2].onClick.AddListener(() => SpawnSoldier(SoldierType.Heavy));
            }
            else
            {
                SoldierButtonsPanel.SetActive(false);
            }
        }

        private void SpawnSoldier(SoldierType type)
        {
            Vector2 spawnPosition = GetValidSpawnPosition();
            if (spawnPosition != Vector2.zero)
            {
                Soldier newSoldier = SoldierFactory.Instance.CreateSoldier(type, spawnPosition);
                _occupiedPositions.Add(spawnPosition); // Track positions
            }
            else
            {
                Debug.LogWarning("No valid spawn position found for soldier.");
            }
        }

        private Vector2 GetValidSpawnPosition()
        {
            for (int i = 0; i < _maxSpawnAttempts; i++)
            {
                Vector2 randomOffset = Random.insideUnitCircle * _spawnRadius;
                var xPosition = _selectedBuildingGameObject.transform.position.x;
                var yPosition = _selectedBuildingGameObject.transform.position.y - Mathf.CeilToInt(_currentBuilding.CellBoundaries.height / 2) - 1;
                Vector2 candidatePosition = new Vector2(xPosition, yPosition) + randomOffset;

                // Check if position is occupied
                if (!IsPositionOccupied(candidatePosition))
                {
                    return candidatePosition;
                }
            }

            return Vector2.zero; // No valid position found
        }

        private bool IsPositionOccupied(Vector2 position)
        {
            foreach (Vector2 occupiedPos in _occupiedPositions)
            {
                if (Vector2.Distance(position, occupiedPos) < 0.5f) // Small buffer
                {
                    return true;
                }
            }

            return false;
        }
    }
}
