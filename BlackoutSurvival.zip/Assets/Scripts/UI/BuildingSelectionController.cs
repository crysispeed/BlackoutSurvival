using System;
using BuildingSystem.Controllers;
using BuildingSystem.Models;
using UI.ViewModels;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.Serialization;

namespace UI
{
    /// <summary>
    /// This class handles the building selection from the list view, and updates the building info view on the right side of the canvas.
    /// </summary>
    public class BuildingSelectionController : MonoBehaviour
    {
        private Camera _mainCamera;

        private void Awake()
        {
            _mainCamera = Camera.main;
        }

        private void Update()
        {
            if (!Input.GetMouseButtonDown(0) || EventSystem.current.IsPointerOverGameObject()) // Ignore UI clicks
                return;

            Vector2 mousePosition = _mainCamera.ScreenToWorldPoint(Input.mousePosition);
            RaycastHit2D hit = Physics2D.Raycast(mousePosition, Vector2.zero, 0f);

            BuildingController buildingController = hit.collider?.GetComponent<BuildingController>();
            if (buildingController != null)
            {
                BuildableItemModel buildingViewModel = buildingController.BuildableItemModel;
                if (buildingViewModel != null)
                {
                    FindObjectOfType<BuildingViewModel>().SelectBuilding(buildingViewModel, buildingController.gameObject);
                    return;
                }
            }

            // If no building is found, close the UI
            FindObjectOfType<BuildingViewModel>().DeselectBuilding();
        }
    }
}
