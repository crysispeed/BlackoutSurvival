using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.Serialization;
using UnityEngine.UI;

namespace UI
{
    public class LogWindow : MonoBehaviour
    {
        public TMP_Text LogText; // Assign the Text UI component in the Inspector
        public ScrollRect ScrollRect; // Assign the Scroll View component
        public GameObject Content;
        public int MaxLogs = 50; // Limit log entries
    
        private Queue<string> _logQueue = new Queue<string>();
        private bool _isVisible = false;

        private void Awake()
        {
            Application.logMessageReceived += HandleLog;
            Content.SetActive(false); // Start hidden
        }

        private void Update()
        {
            if (Input.GetKeyDown(KeyCode.F1)) // Press F1 to toggle log window
            {
                _isVisible = !_isVisible;
                Content.SetActive(_isVisible);
            }
        }

        private void HandleLog(
            string logString,
            string stackTrace,
            LogType type)
        {
            if (_logQueue.Count >= MaxLogs)
            {
                _logQueue.Dequeue();
            }

            _logQueue.Enqueue(logString);

            LogText.text = string.Join("\n", _logQueue.ToArray());

            // Expand content height dynamically
            LogText.rectTransform.sizeDelta = new Vector2(LogText.rectTransform.sizeDelta.x, _logQueue.Count * 20);

            // Force UI update
            Canvas.ForceUpdateCanvases();

            // Only scroll to bottom if user is already near the bottom
            if (ScrollRect.verticalNormalizedPosition <= 0.01f)
            {
                ScrollRect.verticalNormalizedPosition = 0f; // Scroll to bottom
            }
        }

        private void OnDestroy()
        {
            Application.logMessageReceived -= HandleLog;
        }
    }
}
