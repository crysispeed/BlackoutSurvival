using UnityEngine;

namespace Extensions
{
	/// <summary>
	/// This class extends RectInt for iterating the desired rect coordinates to execute the given action on that coordinate values.
	/// This is mainly used for registering and unregistering the coordinate as not empty and checking if the coordinate is empty or not.
	/// </summary>
	public static class RectIntExtension
	{
		public delegate void RectAction(Vector3Int coordinates);

		public delegate bool RectActionCheck(Vector3Int coordinates);

		public static void Iterate(
			this RectInt rect,
			Vector3Int coordinates,
			RectAction action)
		{
			for (int i = rect.x; i < rect.xMax; i++)
			{
				for (int j = rect.y; j < rect.yMax; j++)
				{
					action(coordinates + new Vector3Int(i, j, 0));
				}
			}
		}

		public static bool IterateCheck(
			this RectInt rect,
			Vector3Int coordinates,
			RectActionCheck action)
		{
			for (int i = rect.x; i < rect.xMax; i++)
			{
				for (int j = rect.y; j < rect.yMax; j++)
				{
					if (action(coordinates + new Vector3Int(i, j, 0)))
					{
						return true;
					}
				}
			}

			return false;
		}
	}
}