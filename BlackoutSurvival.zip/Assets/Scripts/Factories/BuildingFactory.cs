using BuildingSystem.Controllers;
using PoolingSystems;
using UnityEngine;

namespace Factories
{
	/// <summary>
	/// This factory class handles the building pooling to reduce the instantiate overhead that will happen when we create too much buildings.
	/// </summary>
	public class BuildingFactory : MonoBehaviour
	{
		public static BuildingFactory Instance { get; private set; }

		public BuildingPool BarracksPool;
		public BuildingPool PowerPlantPool;

		private void Awake()
		{
			if (Instance != null && Instance != this)
			{
				Destroy(gameObject);
				return;
			}

			Instance = this;

			BarracksPool.InitializePool(30);
			PowerPlantPool.InitializePool(30);
		}

		public GameObject CreateBuildingGameObject(BuildingType type, Vector2 position)
		{
			GameObject building = null;

			switch (type)
			{
				case BuildingType.Barracks:
					building = BarracksPool.GetGameObject();
					break;
				case BuildingType.PowerPlant:
					building = PowerPlantPool.GetGameObject();
					break;
			}

			if (building != null)
			{
				building.transform.position = position;
			}

			building.GetComponent<BuildingController>().Initialize();
			return building;
		}

		public void ReturnBuildingGameObject(BuildingType type, GameObject building)
		{
			switch (type)
			{
				case BuildingType.Barracks:
					BarracksPool.ReturnGameObject(building);
					break;
				case BuildingType.PowerPlant:
					PowerPlantPool.ReturnGameObject(building);
					break;
			}
		}
	}

	public enum BuildingType
	{
		Barracks, PowerPlant
	}
}