using PoolingSystems;
using Soldiers;
using UnityEngine;
using UnityEngine.Serialization;

namespace Factories
{
	/// <summary>
	/// This factory class handles the soldier pooling to reduce the instantiate overhead that will happen when we create too much soldiers.
	/// </summary>
	public class SoldierFactory : MonoBehaviour
	{
		public static SoldierFactory Instance { get; private set; }
		
		public SoldierPool InfantryPool;
		public SoldierPool SniperPool;
		public SoldierPool HeavyPool;
		
		private void Awake()
		{
			if (Instance != null && Instance != this)
			{
				Destroy(gameObject);
				return;
			}

			Instance = this;

			InfantryPool.InitializePool(30);
			SniperPool.InitializePool(30);
			HeavyPool.InitializePool(30);
		}

		public Soldier CreateSoldier(SoldierType type, Vector2 position)
		{
			Soldier soldier = null;

			switch (type)
			{
				case SoldierType.Infantry:
					soldier = InfantryPool.GetSoldier();
					break;
				case SoldierType.Sniper:
					soldier = SniperPool.GetSoldier();
					break;
				case SoldierType.Heavy:
					soldier = HeavyPool.GetSoldier();
					break;
			}

			if (soldier != null)
			{
				soldier.transform.position = position;
			}

			soldier.Initialize();
			return soldier;
		}

		public void ReturnSoldier(Soldier soldier)
		{
			switch (soldier)
			{
				case Heavy heavy:
					HeavyPool.ReturnSoldier(heavy);
					break;
				case Infantry infantry:
					InfantryPool.ReturnSoldier(infantry);
					break;
				case Sniper sniper:
					SniperPool.ReturnSoldier(sniper);
					break;
			}
		}
	}

	public enum SoldierType
	{
		Infantry, Sniper, Heavy
	}
}