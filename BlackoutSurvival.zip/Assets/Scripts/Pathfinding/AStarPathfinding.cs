using System.Collections.Generic;
using UnityEngine;

namespace Pathfinding
{
	/// <summary>
	/// Standard A* pathfinding algorithm class that we are using for moving the selected soldiers to the right-clicked position.
	/// </summary>
	public class AStarPathfinding : MonoBehaviour
	{
		public static List<Vector2Int> FindPath(Vector2Int start, Vector2Int end)
		{
			GridManager gridManager = GridManager.Instance;
			if (!gridManager.GetNode(end)?.IsWalkable ?? true)
			{
				Debug.Log("Target position is not walkable!");
				return null;
			}

			List<Node> openSet = new List<Node>();
			HashSet<Node> closedSet = new HashSet<Node>();

			Node startNode = gridManager.GetNode(start);
			Node endNode = gridManager.GetNode(end);

			if (startNode == null || endNode == null) return null;

			openSet.Add(startNode);

			while (openSet.Count > 0)
			{
				Node currentNode = openSet[0];

				for (int i = 1; i < openSet.Count; i++)
				{
					if (openSet[i].FCost < currentNode.FCost ||
					    (openSet[i].FCost == currentNode.FCost && openSet[i].HCost < currentNode.HCost))
					{
						currentNode = openSet[i];
					}
				}

				openSet.Remove(currentNode);
				closedSet.Add(currentNode);

				if (currentNode == endNode)
				{
					return RetracePath(startNode, endNode);
				}

				foreach (Node neighbor in gridManager.GetNeighbors(currentNode))
				{
					if (closedSet.Contains(neighbor)) continue;

					int newMovementCost = currentNode.GCost + 10;
					if (newMovementCost < neighbor.GCost || !openSet.Contains(neighbor))
					{
						neighbor.GCost = newMovementCost;
						neighbor.HCost = GetDistance(neighbor, endNode);
						neighbor.Parent = currentNode;

						if (!openSet.Contains(neighbor))
							openSet.Add(neighbor);
					}
				}
			}

			return null;
		}

		private static List<Vector2Int> RetracePath(Node startNode, Node endNode)
		{
			List<Vector2Int> path = new List<Vector2Int>();
			Node currentNode = endNode;

			while (currentNode != startNode)
			{
				path.Add(currentNode.Position);
				currentNode = currentNode.Parent;
			}

			path.Reverse();
			return path;
		}

		private static int GetDistance(Node a, Node b)
		{
			int dx = Mathf.Abs(a.Position.x - b.Position.x);
			int dy = Mathf.Abs(a.Position.y - b.Position.y);
			return dx + dy;
		}
	}
}