using UnityEngine;

namespace Pathfinding
{
    /// <summary>
    /// Node class that is used for A* pathfinding algorithm. 
    /// Boolean flag 
    /// </summary>
    public class Node
    {
        /// <summary>
        /// Position of the node.
        /// </summary>
        public Vector2Int Position;
        /// <summary>
        /// Boolean flag that shows whether it is walkable or not.
        /// </summary>
        public bool IsWalkable;
        /// <summary>
        /// GCost of the node.
        /// </summary>
        public int GCost;
        /// <summary>
        /// HCost of the node.
        /// </summary>
        public int HCost;
        /// <summary>
        /// Parent of this node.
        /// </summary>
        public Node Parent;

        /// <summary>
        /// FCost of this node.
        /// </summary>
        public int FCost => GCost + HCost;

        public Node(Vector2Int position, bool isWalkable)
        {
            Position = position;
            IsWalkable = isWalkable;
            GCost = int.MaxValue;
            HCost = 0;
            Parent = null;
        }
    }
}
