using System.Collections.Generic;
using System.Linq;
using BuildingSystem.Controllers;
using BuildingSystem.TilemapLayerLogic;
using UnityEngine;
using UnityEngine.Serialization;
using UnityEngine.Tilemaps;

namespace Pathfinding
{
    /// <summary>
    /// This class handles the gris that A* pathfinding can be executed on desired grid size. Right now, we have 70x40 playable size that player can move their soldiers.
    /// </summary>
    public class GridManager : MonoBehaviour
    {
        public static GridManager Instance { get; private set; }
        
        [FormerlySerializedAs("tilemap")] 
        public Tilemap Tilemap; // Reference to your tilemap holding buildings
        [FormerlySerializedAs("gridSize")] 
        public Vector2Int GridSize; // Set based on your tilemap

        [FormerlySerializedAs("_constructionLayer")] [SerializeField]
        private BuildingLayer BuildingLayer;
        private Dictionary<Vector2Int, Node> _grid = new Dictionary<Vector2Int, Node>();

        private void Awake()
        {
            if (Instance != null && Instance != this)
            {
                Destroy(gameObject);
                return;
            }

            Instance = this;
            GenerateGrid();
        }
        
        /// <summary>
        /// Grid's center is (0,0) so the top left of the grid becomes -GridSize.x / 2, same goes for the y-axis.
        /// <remarks>This grid need to be generated again every time we remove or set new building to update the walkable positions.</remarks>
        /// </summary>
        public void GenerateGrid()
        {
            _grid.Clear();
            for (int x = -(GridSize.x / 2); x < GridSize.x / 2; x++)
            {
                for (int y = -(GridSize.y / 2); y < GridSize.y / 2; y++)
                {
                    Vector2Int pos = new Vector2Int(x, y);
                    bool isWalkable = Tilemap.GetTile((Vector3Int)pos) == null && !IsObjectAtPosition(pos); // Walkable if no tile
                    _grid[pos] = new Node(pos, isWalkable);
                }
            }
        }

        private bool IsObjectAtPosition(Vector2 position)
        {
            Collider2D hitCollider = Physics2D.OverlapPoint(position);
            return hitCollider != null;
        }
        
        public Node GetNode(Vector2Int position)
        {
            return _grid.ContainsKey(position) ? _grid[position] : null;
        }

        public List<Node> GetNeighbors(Node node)
        {
            List<Node> neighbors = new List<Node>();
            Vector2Int[] directions = { Vector2Int.up, Vector2Int.down, Vector2Int.left, Vector2Int.right };

            foreach (Vector2Int dir in directions)
            {
                Vector2Int neighborPos = node.Position + dir;
                if (_grid.ContainsKey(neighborPos) && _grid[neighborPos].IsWalkable)
                {
                    neighbors.Add(_grid[neighborPos]);
                }
            }

            return neighbors;
        }
        
        public Vector2 GetClosestValidTile(Vector2 buildingPosition, Vector2 soldierPosition, BuildingController target, float gap)
        {
            var cellBoundaryX = target.BuildableItemModel.CellBoundaries.width / 2;
            var cellBoundaryY = target.BuildableItemModel.CellBoundaries.height / 2;
            
            // Define the outer ring around the building
            float minX = buildingPosition.x - cellBoundaryX - gap;
            float maxX = buildingPosition.x + cellBoundaryX + gap;
            float minY = buildingPosition.y - cellBoundaryX - gap;
            float maxY = buildingPosition.y + cellBoundaryX + gap;
            
            // Randomly choose a side: Top, Bottom, Left, or Right
            int side = Random.Range(0, 4);
            Vector2 randomPosition = Vector2.zero;

            switch (side)
            {
                case 0: // Top
                    randomPosition = new Vector2(Random.Range(minX, maxX), maxY);
                    break;
                case 1: // Bottom
                    randomPosition = new Vector2(Random.Range(minX, maxX), minY);
                    break;
                case 2: // Left
                    randomPosition = new Vector2(minX, Random.Range(minY, maxY));
                    break;
                case 3: // Right
                    randomPosition = new Vector2(maxX, Random.Range(minY, maxY));
                    break;
            }

            // Default to entrance of building
            return IsObjectAtPosition(randomPosition) ? new Vector2(buildingPosition.x, cellBoundaryY) : randomPosition;
        }

        public Vector2 GetNearestValidAttackPosition(
            Vector2 targetPosition,
            Vector2 currentPosition,
            float gap)
        {
            List<Vector2> possiblePositions = new List<Vector2>
            {
                targetPosition + Vector2.up * gap,
                targetPosition + Vector2.down * gap,
                targetPosition + Vector2.left * gap,
                targetPosition + Vector2.right * gap
            };

            foreach (var pos in possiblePositions)
            {
                if (!IsObjectAtPosition(pos))
                {
                    return pos;
                }
            }

            return currentPosition; // Default to staying in place if no position is valid
        }
        
    }
}
