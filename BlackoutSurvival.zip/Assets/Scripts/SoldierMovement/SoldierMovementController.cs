using System.Collections.Generic;
using BuildingSystem.Controllers;
using Soldiers;
using UnityEngine;
using UnityEngine.EventSystems;

namespace SoldierMovement
{
    /// <summary>
    /// This class handles the soldier actions like right-click to move the selected soldiers, select building for the attack and select a soldier to attack.
    /// </summary>
    public class SoldierMovementController : MonoBehaviour
    {
        private Camera _mainCamera;
        private List<Soldier> _selectedSoldiers = new List<Soldier>();
        private Vector2 _selectionStart;
        private Vector2 _selectionEnd;
        private bool _isSelecting = false;
        
        private void Start()
        {
            _mainCamera = Camera.main;
        }

        private void Update()
        {
            if (EventSystem.current.IsPointerOverGameObject()) // Ignore UI clicks
                return;

            if (Input.GetMouseButtonDown(0)) // Start Selection
            {
                DeselectAllSoldiers();
                _selectionStart = _mainCamera.ScreenToWorldPoint(Input.mousePosition);
                _isSelecting = true;
            }
            else if (Input.GetMouseButtonUp(0)) // End Selection & Select Soldiers
            {
                _selectionEnd = _mainCamera.ScreenToWorldPoint(Input.mousePosition);
                SelectSoldiersInArea(_selectionStart, _selectionEnd);
                _isSelecting = false;
            }
            else if (Input.GetMouseButtonDown(1) && _selectedSoldiers.Count > 0) // Move Selected Soldiers
            {
                Vector2 mouseWorldPos = _mainCamera.ScreenToWorldPoint(Input.mousePosition);
                Collider2D hitCollider = Physics2D.OverlapPoint(mouseWorldPos);
                
                if (hitCollider != null)
                {
                    if (hitCollider.GetComponent<BuildingController>() != null) // If we selected a building, attack!
                    {
                        BuildingController targetBuilding = hitCollider.GetComponent<BuildingController>();
                        if (targetBuilding != null)
                        {
                            foreach (Soldier soldier in _selectedSoldiers)
                            {
                                soldier.MoveAndAttackBuilding(targetBuilding, _selectedSoldiers);
                            }
                        }
                    }
                    else if (hitCollider.GetComponent<Soldier>() != null) // If selected one is a soldier, attack!
                    {
                        Soldier targetSoldier = hitCollider.GetComponent<Soldier>();
                        foreach (Soldier soldier in _selectedSoldiers)
                        {
                            soldier.MoveAndAttackSoldier(targetSoldier);
                        }
                    }
                }
                else
                {
                    // Move soldiers normally if no building is clicked
                    MoveSelectedSoldiers();
                }
            }
        }

        private void OnGUI()
        {
            if (_isSelecting)
            {
                DrawSelectionBox();
            }
        }

        private void DrawSelectionBox()
        {
            Vector2 screenStart = _mainCamera.WorldToScreenPoint(_selectionStart);
            Vector2 screenEnd = Input.mousePosition; // No need to convert this, as it's already in screen space

            float x = Mathf.Min(screenStart.x, screenEnd.x);
            float y = Mathf.Min(Screen.height - screenStart.y, Screen.height - screenEnd.y);
            float width = Mathf.Abs(screenEnd.x - screenStart.x);
            float height = Mathf.Abs((Screen.height - screenEnd.y) - (Screen.height - screenStart.y));

            Rect rect = new Rect(x, y, width, height);

            GUI.color = new Color(0, 1, 0, 0.3f); // Green transparent
            GUI.DrawTexture(rect, Texture2D.whiteTexture);
        }
        
        private void SelectSoldiersInArea(Vector2 start, Vector2 end)
        {
            _selectedSoldiers.Clear();

            Vector2 min = Vector2.Min(start, end);
            Vector2 max = Vector2.Max(start, end);

            Collider2D[] colliders = Physics2D.OverlapAreaAll(min, max);
            foreach (Collider2D col in colliders)
            {
                Soldier soldier = col.GetComponent<Soldier>();
                if (soldier != null)
                {
                    _selectedSoldiers.Add(soldier);
                    soldier.SetSoldierSelected(true);
                }
            }

            Debug.Log("Selected Soldiers: " + _selectedSoldiers.Count);
        }

        // Deselect all selected soldiers
        private void DeselectAllSoldiers()
        {
            foreach (Soldier soldier in _selectedSoldiers)
            {
                soldier.SetSoldierSelected(false);
            }
            _selectedSoldiers.Clear();
            Debug.Log("All soldiers deselected.");
        }
        
        private void MoveSelectedSoldiers()
        {
            Vector2 targetPosition = _mainCamera.ScreenToWorldPoint(Input.mousePosition);

            int rowCount = Mathf.CeilToInt(Mathf.Sqrt(_selectedSoldiers.Count));
            float spacing = 0.5f; // Space between soldiers

            for (int i = 0; i < _selectedSoldiers.Count; i++)
            {
                int row = i / rowCount;
                int col = i % rowCount;
                Vector2 offset = new Vector2(col * spacing, row * spacing);

                _selectedSoldiers[i].MoveTo(targetPosition + offset);
            }
        }
    }
}
