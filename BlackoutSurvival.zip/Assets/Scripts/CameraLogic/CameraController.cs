using GameInput;
using UnityEngine;

namespace CameraLogic
{
    /// <summary>
    /// This class controls the movement and size of the camera. WASD moves the camera and mouse scroll controls the size of the camera. 
    /// </summary>
    public class CameraController : MonoBehaviour
    {
        private const float MIN_ZOOM = 8f;
        private const float MAX_ZOOM = 18f;
    
        private Camera _mainCamera; 
        private float _targetZoom;
        private float _zoomVelocity = 0f; // Used for SmoothDamp

        // Camera Movement Fields
        [Header("Movement Settings")]
        public float MoveSpeed = 15f; // Base speed
        public float SmoothTime = 0.2f; // Smoothing factor
    
        private Vector2 _moveDirection = Vector2.zero; // Target movement direction
        private Vector2 _currentVelocity = Vector2.zero; // Used for smooth movement
        private Vector2 _smoothedMoveDirection = Vector2.zero;
    
        // Start is called before the first frame update
        void Start()
        {
            if (_mainCamera == null)
                _mainCamera = Camera.main;

            _targetZoom = _mainCamera.orthographicSize;
        }

        // Update is called once per frame
        void Update()
        {
            UpdateCameraZoom();
            UpdateCameraPosition();
        }

        private void UpdateCameraZoom()
        {
            float scrollWheelValue = MouseInputController.Instance.GetMouseScrollWheelValue();

            if (scrollWheelValue > 0) // Scrolling up
                _targetZoom -= 1f;
            else if (scrollWheelValue < 0) // Scrolling down
                _targetZoom += 1f;

            // Clamp zoom between min and max
            _targetZoom = Mathf.Clamp(_targetZoom, MIN_ZOOM, MAX_ZOOM);

            _mainCamera.orthographicSize = Mathf.SmoothDamp(_mainCamera.orthographicSize, _targetZoom, ref _zoomVelocity, 0.2f);
        }

        private void UpdateCameraPosition()
        {
            KeyboardButton currentButton = KeyboardInputController.Instance.GetCurrentKeyboardButton();
        
            switch (currentButton)
            {
                case KeyboardButton.MoveUp:
                    _smoothedMoveDirection = Vector2.up;
                    break;
                case KeyboardButton.MoveDown:
                    _smoothedMoveDirection = Vector2.down;
                    break;
                case KeyboardButton.MoveLeft:
                    _smoothedMoveDirection = Vector2.left;
                    break;
                case KeyboardButton.MoveRight:
                    _smoothedMoveDirection = Vector2.right;
                    break;
                default:
                    _smoothedMoveDirection = Vector2.zero;
                    break;
            }

            // Smoothly transition movement
            _smoothedMoveDirection = Vector2.SmoothDamp(_smoothedMoveDirection, _moveDirection, ref _currentVelocity, SmoothTime);

            // Apply movement
            Vector3 movement = new Vector3(_smoothedMoveDirection.x, _smoothedMoveDirection.y, 0) * (MoveSpeed * Time.deltaTime);
            transform.position += movement;
        
        }
    }
}
