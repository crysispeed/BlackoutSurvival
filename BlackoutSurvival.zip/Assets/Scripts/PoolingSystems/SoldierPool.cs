using System.Collections.Generic;
using Soldiers;
using UnityEngine;
using UnityEngine.Serialization;

namespace PoolingSystems
{
    /// <summary>
    /// Pool class for soldiers.
    /// </summary>
    public class SoldierPool : MonoBehaviour
    {
        public Soldier SoldierPrefab; // Prefab to create
        private Queue<Soldier> _pool = new Queue<Soldier>();

        public void InitializePool(int count)
        {
            for (int i = 0; i < count; i++)
            {
                Soldier soldier = Instantiate(SoldierPrefab, transform);
                soldier.gameObject.SetActive(false);
                _pool.Enqueue(soldier);
            }
        }

        public Soldier GetSoldier()
        {
            if (_pool.Count > 0)
            {
                Soldier soldier = _pool.Dequeue();
                soldier.gameObject.SetActive(true);
                return soldier;
            }
            else
            {
                // Expand pool if empty
                Soldier soldier = Instantiate(SoldierPrefab, transform);
                return soldier;
            }
        }

        public void ReturnSoldier(Soldier soldier)
        {
            soldier.gameObject.SetActive(false);
            _pool.Enqueue(soldier);
        }
    }
}
