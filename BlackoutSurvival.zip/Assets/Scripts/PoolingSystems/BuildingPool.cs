using System.Collections.Generic;
using BuildingSystem.Controllers;
using UnityEngine;

namespace PoolingSystems
{
    /// <summary>
    /// Pool class for buildings.
    /// </summary>
    public class BuildingPool : MonoBehaviour
    {
        public GameObject GameObjectPrefab; // Prefab to create
        private Queue<GameObject> _pool = new Queue<GameObject>();

        public void InitializePool(int count)
        {
            for (int i = 0; i < count; i++)
            {
                GameObject building = Instantiate(GameObjectPrefab, transform);
                building.gameObject.SetActive(false);
                _pool.Enqueue(building);
            }
        }

        public GameObject GetGameObject()
        {
            if (_pool.Count > 0)
            {
                GameObject soldier = _pool.Dequeue();
                soldier.gameObject.SetActive(true);
                return soldier;
            }
            else
            {
                // Expand pool if empty
                GameObject soldier = Instantiate(GameObjectPrefab, transform);
                return soldier;
            }
        }

        public void ReturnGameObject(GameObject soldier)
        {
            soldier.gameObject.SetActive(false);
            _pool.Enqueue(soldier);
        }
    }
}
